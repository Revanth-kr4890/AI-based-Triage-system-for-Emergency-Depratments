---
title: AI Triage System
emoji: 🏥
colorFrom: red
colorTo: blue
sdk: docker
pinned: false
---

# 🏥 AI ED Triage System

An Emergency Department Triage reinforcement learning environment where an AI agent prioritizes, treats, and discharges patients to minimize mortality and maximize throughput.

## 🧠 Problem

Emergency departments face constant pressure to triage patients correctly under time constraints. Mis-triaging a critical patient (assigning them lower priority than they need) can be fatal. This simulation models that challenge as an RL environment.

## 🏗️ Approach

- **Environment** (`environment.py`): Simulates an ED with arriving patients, beds, vitals, mortality risk, and realistic complaint/severity distributions using a seeded PRNG for reproducibility.
- **Grader** (`grader.py`): Normalised 0–1 scoring based on reward ratio (35%), triage accuracy (25%), throughput (15%), mortality penalty (15%), and prioritization bonus (10%).
- **Baseline Agent** (`baseline.py`): Simple rule-based bot — triages by SpO₂, treats highest acuity first, discharges to free beds.
- **Tasks** (`tasks.py`): Three difficulty levels — Easy (2 patients, 10 beds), Medium (5 patients, 8 beds), Hard (10+ patients, 2 beds).

## 🔌 API Endpoints

| Endpoint | Method | Description |
|-----------|--------|-------------|
| `/` | GET | Health check |
| `/reset` | POST | Start new simulation (optional: `totalBeds`, `maxTicks`, `arrivalRate`, `seed`) |
| `/state` | GET | Current environment snapshot |
| `/step` | POST | Submit action (`triage`, `treat`, `discharge`, `noop`) |
| `/tasks` | GET | List scenario configurations |
| `/grader` | GET | Normalised 0–1 performance report |
| `/baseline` | POST | Run baseline agent to completion |

## 🚀 Quick Start

```bash
# Test locally
pip install -r requirements.txt
uvicorn app:app --host 0.0.0.0 --port 7860

# Or with Docker
docker build -t ai-triage .
docker run -p 7860:7860 ai-triage
```

## 📡 Example Usage

```bash
# Reset environment
curl -X POST http://localhost:7860/reset

# Get current state
curl http://localhost:7860/state

# Take an action
curl -X POST http://localhost:7860/step \
  -H "Content-Type: application/json" \
  -d '{"type": "treat", "patientId": "P-001"}'

# Check score
curl http://localhost:7860/grader

# Run baseline agent
curl -X POST http://localhost:7860/baseline
```

## 📊 Grading Weights

| Component | Weight | Description |
|-----------|--------|-------------|
| Reward Ratio | 35% | Cumulative reward / max possible |
| Triage Accuracy | 25% | Correct ESI assignments |
| Throughput | 15% | Discharged / total arrivals |
| Mortality | 15% | Penalty per death event |
| Prioritization | 10% | Treated high-acuity before low |

## 📁 Files

- `app.py` — FastAPI server with all endpoints
- `environment.py` — Core RL environment simulation
- `grader.py` — Performance scoring system
- `baseline.py` — Rule-based baseline agent
- `tasks.py` — Easy/Medium/Hard scenario configs
- `openenv.yaml` — Environment specification
- `Dockerfile` — Container configuration
