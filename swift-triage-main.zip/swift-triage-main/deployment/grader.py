"""Grader: normalised 0-1 score from cumulative reward and metrics."""


def compute_critical_delay_penalty(state: dict) -> float:
    waiting = [p for p in state["patients"] if p["status"] == "waiting"]
    penalty = 0.0
    for p in waiting:
        if p["esiLevel"] <= 2:
            penalty += 0.02 * (6 - p["esiLevel"])
    return min(0.15, penalty)


def compute_prioritization_bonus(action_log: list) -> float:
    treats = [a for a in action_log if a["action"].get("type") == "treat"]
    if len(treats) < 2:
        return 1.0
    correct = 0
    total = 0
    for i in range(1, len(treats)):
        total += 1
        if treats[i - 1]["reward"] >= treats[i]["reward"]:
            correct += 1
    return correct / total if total > 0 else 1.0


def grade(state: dict, cumulative_reward: float, action_log: list) -> dict:
    m = state["metrics"]
    total_reward = cumulative_reward

    perfect = max(1, m["totalArrivals"] * 10 + m["totalArrivals"] * 6 + m["totalArrivals"] * 3 - state["tick"] * 0.5)
    triage_acc = 1.0 if m["totalMistriage"] == 0 else max(0, 1 - m["totalMistriage"] / max(1, m["totalArrivals"]))
    throughput = m["totalDischarged"] / m["totalArrivals"] if m["totalArrivals"] > 0 else 0
    cdp = compute_critical_delay_penalty(state)
    pb = compute_prioritization_bonus(action_log)

    rr = max(0, min(1, total_reward / perfect))
    weighted = (
        rr * 0.35
        + triage_acc * 0.25
        + throughput * 0.15
        + pb * 0.10
        + max(0, 0.15 - m["mortalityEvents"] * 0.05)
        + max(0, 0 - cdp)
    )
    score = max(0.0, min(1.0, round(weighted, 4)))

    return {
        "score": score,
        "totalReward": total_reward,
        "maxPossibleReward": round(perfect, 1),
        "triageAccuracy": round(triage_acc, 3),
        "mortalityEvents": m["mortalityEvents"],
        "avgWaitMinutes": m["avgWaitMinutes"],
        "throughput": round(throughput, 3),
        "criticalDelayPenalty": round(cdp, 3),
        "prioritizationBonus": round(pb, 3),
        "breakdown": {
            "rewardRatio": round(rr * 0.35, 4),
            "triageComponent": round(triage_acc * 0.25, 4),
            "throughputComponent": round(throughput * 0.15, 4),
            "mortalityPenalty": round(max(0, 0.15 - m["mortalityEvents"] * 0.05), 4),
            "waitPenalty": round(min(0.1, m["avgWaitMinutes"] / 500), 4),
            "criticalDelayPenalty": round(-cdp, 4),
            "prioritizationBonus": round(pb * 0.10, 4),
        },
    }
