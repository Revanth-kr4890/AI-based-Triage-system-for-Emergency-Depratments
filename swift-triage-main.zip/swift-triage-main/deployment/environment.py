"""ED Triage Reinforcement Learning Environment."""
import math
import copy
from dataclasses import dataclass, field
from typing import Literal

ESILevel = Literal[1, 2, 3, 4, 5]
PatientStatus = Literal["waiting", "treating", "discharged"]

COMPLAINTS = [
    {"complaint": "Cardiac arrest", "trueESI": 1, "vitals": {"hr": 0, "bp": "60/40", "temp": 35.0, "spo2": 70, "rr": 4}},
    {"complaint": "Chest pain radiating to arm", "trueESI": 1, "vitals": {"hr": 120, "bp": "180/110", "temp": 37.2, "spo2": 88, "rr": 26}},
    {"complaint": "Severe respiratory distress", "trueESI": 2, "vitals": {"hr": 110, "bp": "140/90", "temp": 37.8, "spo2": 85, "rr": 30}},
    {"complaint": "Active GI bleed", "trueESI": 2, "vitals": {"hr": 105, "bp": "95/60", "temp": 36.9, "spo2": 94, "rr": 22}},
    {"complaint": "Abdominal pain, vomiting", "trueESI": 3, "vitals": {"hr": 92, "bp": "130/85", "temp": 38.4, "spo2": 97, "rr": 18}},
    {"complaint": "Deep laceration, bleeding controlled", "trueESI": 3, "vitals": {"hr": 84, "bp": "125/80", "temp": 36.8, "spo2": 98, "rr": 16}},
    {"complaint": "Ankle injury, unable to bear weight", "trueESI": 4, "vitals": {"hr": 76, "bp": "118/72", "temp": 36.9, "spo2": 99, "rr": 14}},
    {"complaint": "Mild rash, itching", "trueESI": 5, "vitals": {"hr": 72, "bp": "115/70", "temp": 36.6, "spo2": 99, "rr": 14}},
    {"complaint": "Sore throat, low-grade fever", "trueESI": 5, "vitals": {"hr": 78, "bp": "120/75", "temp": 38.0, "spo2": 99, "rr": 16}},
    {"complaint": "Headache, no red flags", "trueESI": 4, "vitals": {"hr": 80, "bp": "128/78", "temp": 36.7, "spo2": 99, "rr": 15}},
]

NAMES = [
    "Alex Rivera", "Jordan Lee", "Casey Patel", "Morgan Wu", "Riley Adams",
    "Taylor Kim", "Quinn Foster", "Avery Singh", "Drew Nakamura", "Sam Okafor",
    "Jamie Cruz", "Reese Chang", "Skyler Youssef", "Finley Brooks", "Dakota Ahn",
]


class SeededRandom:
    def __init__(self, seed: int):
        self.s = seed

    def random(self) -> float:
        self.s = (self.s * 16807) % 2147483647
        return self.s / 2147483647


def jitter_vitals(base: dict, rand: SeededRandom) -> dict:
    def jit(v, pct):
        return round(v * (1 + (rand.random() - 0.5) * pct), 1)

    sys, dia = map(int, base["bp"].split("/"))
    return {
        "hr": round(jit(base["hr"], 0.15)),
        "bp": f"{round(jit(sys, 0.1))}/{round(jit(dia, 0.1))}",
        "temp": jit(base["temp"], 0.02),
        "spo2": min(100, max(50, round(jit(base["spo2"], 0.05)))),
        "rr": round(jit(base["rr"], 0.15)),
    }


class EDTriageEnvironment:
    def __init__(self, total_beds=20, max_ticks=100, arrival_rate=1.5, seed=42):
        self.total_beds = total_beds
        self.max_ticks = max_ticks
        self.arrival_rate = arrival_rate
        self.seed = seed
        self.rand = SeededRandom(seed)
        self.patient_counter = 0
        self.true_esi_map: dict[str, int] = {}
        self._state = {}
        self.reset()

    def reset(self) -> dict:
        self.rand = SeededRandom(self.seed)
        self.patient_counter = 0
        self.true_esi_map.clear()
        initial = self._generate_patients(5)
        self._state = {
            "tick": 0,
            "patients": initial,
            "beds": {"total": self.total_beds, "occupied": 0},
            "metrics": {
                "totalArrivals": len(initial),
                "totalDischarged": 0,
                "totalMistriage": 0,
                "avgWaitMinutes": 0,
                "mortalityEvents": 0,
            },
            "done": False,
        }
        return self.state()

    def state(self) -> dict:
        return copy.deepcopy(self._state)

    def step(self, action: dict) -> dict:
        if self._state["done"]:
            return {"state": self.state(), "reward": 0, "done": True, "info": {"error": "episode_over"}}

        reward = 0
        info = {}
        atype = action.get("type")

        if atype == "triage":
            p = self._find_patient(action["patientId"])
            if not p:
                reward -= 1; info["error"] = "patient_not_found"
            else:
                true_esi = self.true_esi_map[p["id"]]
                assigned = action["assignedESI"]
                p["esiLevel"] = assigned
                diff = abs(assigned - true_esi)
                if diff == 0:
                    reward += 10; info["triageAccuracy"] = "correct"
                else:
                    penalty = diff * -8 if assigned > true_esi else diff * -3
                    reward += penalty
                    self._state["metrics"]["totalMistriage"] += 1
                    info["triageAccuracy"] = "incorrect"; info["trueESI"] = true_esi

        elif atype == "treat":
            p = self._find_patient(action["patientId"])
            if not p or p["status"] != "waiting":
                reward -= 1; info["error"] = "not_waiting" if p else "patient_not_found"
            elif self._state["beds"]["occupied"] >= self._state["beds"]["total"]:
                reward -= 2; info["error"] = "no_beds"
            else:
                p["status"] = "treating"
                self._state["beds"]["occupied"] += 1
                reward += (6 - p["esiLevel"]) * 2

        elif atype == "discharge":
            p = self._find_patient(action["patientId"])
            if not p or p["status"] != "treating":
                reward -= 1; info["error"] = "not_treating" if p else "patient_not_found"
            else:
                p["status"] = "discharged"
                self._state["beds"]["occupied"] = max(0, self._state["beds"]["occupied"] - 1)
                self._state["metrics"]["totalDischarged"] += 1
                reward += 3

        # Mortality check
        for p in self._state["patients"]:
            if p["status"] == "waiting":
                wait_min = self._state["tick"] * 5
                true_esi = self.true_esi_map.get(p["id"], 3)
                if true_esi <= 2 and wait_min > 15:
                    chance = 0.08 if true_esi == 1 else 0.02
                    if self.rand.random() < chance:
                        self._state["metrics"]["mortalityEvents"] += 1
                        p["status"] = "discharged"
                        reward -= 50
                        info["mortalityEvent"] = p["id"]

        # New arrivals
        num = self._poisson(self.arrival_rate)
        if num > 0:
            new_p = self._generate_patients(num)
            self._state["patients"].extend(new_p)
            self._state["metrics"]["totalArrivals"] += num

        # Update avg wait
        waiting = [p for p in self._state["patients"] if p["status"] == "waiting"]
        self._state["metrics"]["avgWaitMinutes"] = (
            round(sum(self._state["tick"] * 5 for _ in waiting) / len(waiting)) if waiting else 0
        )

        self._state["tick"] += 1
        if self._state["tick"] >= self.max_ticks:
            self._state["done"] = True
        reward -= 0.5

        return {"state": self.state(), "reward": reward, "done": self._state["done"], "info": info}

    def _find_patient(self, pid: str):
        return next((p for p in self._state["patients"] if p["id"] == pid), None)

    def _generate_patients(self, count: int) -> list:
        patients = []
        for _ in range(count):
            self.patient_counter += 1
            t = COMPLAINTS[int(self.rand.random() * len(COMPLAINTS)) % len(COMPLAINTS)]
            name = NAMES[int(self.rand.random() * len(NAMES)) % len(NAMES)]
            pid = f"P-{self.patient_counter:03d}"
            patient = {
                "id": pid, "name": name,
                "age": int(self.rand.random() * 70) + 10,
                "gender": ["M", "F", "O"][int(self.rand.random() * 3) % 3],
                "chiefComplaint": t["complaint"],
                "esiLevel": 3, "status": "waiting",
                "arrivalTime": "2025-01-01T00:00:00Z",
                "vitals": jitter_vitals(t["vitals"], self.rand),
                "painScale": int(self.rand.random() * 10) + 1,
            }
            self.true_esi_map[pid] = t["trueESI"]
            patients.append(patient)
        return patients

    def _poisson(self, lam: float) -> int:
        L = math.exp(-lam)
        k, p = 0, 1.0
        while True:
            k += 1
            p *= self.rand.random()
            if p <= L:
                break
        return k - 1
