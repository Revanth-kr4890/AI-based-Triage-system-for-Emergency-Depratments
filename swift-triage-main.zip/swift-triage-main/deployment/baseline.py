"""Baseline agent: simple rule-based bot that plays the environment."""
from environment import EDTriageEnvironment
from grader import grade


def run_baseline(env: EDTriageEnvironment) -> dict:
    state = env.reset()
    action_log = []
    cumulative_reward = 0.0

    while not state["done"]:
        action = _decide(state)
        result = env.step(action)
        cumulative_reward += result["reward"]
        action_log.append({"tick": result["state"]["tick"], "action": action, "reward": result["reward"]})
        state = result["state"]

    report = grade(state, cumulative_reward, action_log)
    return {"finalState": state, "grade": report}


def _decide(state: dict) -> dict:
    patients = state["patients"]
    waiting = [p for p in patients if p["status"] == "waiting"]
    treating = [p for p in patients if p["status"] == "treating"]
    beds_available = state["beds"]["total"] - state["beds"]["occupied"]

    # Triage critical-looking patients
    for p in waiting:
        if p["esiLevel"] == 3 and p["vitals"]["spo2"] < 90:
            esi = 1 if p["vitals"]["spo2"] < 80 else 2
            return {"type": "triage", "patientId": p["id"], "assignedESI": esi}

    # Treat highest acuity
    if waiting and beds_available > 0:
        best = min(waiting, key=lambda p: p["esiLevel"])
        return {"type": "treat", "patientId": best["id"]}

    # Discharge
    if treating:
        return {"type": "discharge", "patientId": treating[0]["id"]}

    return {"type": "noop"}
