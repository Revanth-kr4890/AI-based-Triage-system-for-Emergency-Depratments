"""FastAPI application — ED Triage RL Environment API."""
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional
from environment import EDTriageEnvironment
from grader import grade
from baseline import run_baseline
from tasks import TASKS

app = FastAPI(
    title="ED Triage RL Environment",
    description="Emergency Department Triage simulation API for AI agent evaluation.",
    version="1.0.0",
)

# ─── Global state ────────────────────────────────────────────────────────────
env = EDTriageEnvironment()
action_log: list[dict] = []
cumulative_reward: float = 0.0


# ─── Models ──────────────────────────────────────────────────────────────────
class ActionBody(BaseModel):
    type: str  # triage | treat | discharge | noop
    patientId: Optional[str] = None
    assignedESI: Optional[int] = None


class ResetBody(BaseModel):
    totalBeds: Optional[int] = None
    maxTicks: Optional[int] = None
    arrivalRate: Optional[float] = None
    seed: Optional[int] = None


# ─── Endpoints ───────────────────────────────────────────────────────────────

@app.get("/")
def root():
    return {"status": "running", "env": "ed-triage-env", "version": "1.0.0"}


@app.post("/reset")
def reset(body: Optional[ResetBody] = None):
    global env, action_log, cumulative_reward
    kwargs = {}
    if body:
        if body.totalBeds is not None: kwargs["total_beds"] = body.totalBeds
        if body.maxTicks is not None: kwargs["max_ticks"] = body.maxTicks
        if body.arrivalRate is not None: kwargs["arrival_rate"] = body.arrivalRate
        if body.seed is not None: kwargs["seed"] = body.seed
    if kwargs:
        env = EDTriageEnvironment(**kwargs)
    action_log = []
    cumulative_reward = 0.0
    return env.reset()


@app.get("/state")
def state():
    return env.state()


@app.post("/step")
def step(action: ActionBody):
    global cumulative_reward
    act = {"type": action.type}
    if action.patientId: act["patientId"] = action.patientId
    if action.assignedESI is not None: act["assignedESI"] = action.assignedESI
    result = env.step(act)
    cumulative_reward += result["reward"]
    action_log.append({"tick": result["state"]["tick"], "action": act, "reward": result["reward"]})
    return result


@app.get("/tasks")
def tasks():
    return TASKS


@app.get("/grader")
def grader():
    return grade(env.state(), cumulative_reward, action_log)


@app.post("/baseline")
def baseline():
    global env, action_log, cumulative_reward
    env = EDTriageEnvironment()
    action_log = []
    cumulative_reward = 0.0
    return run_baseline(env)
