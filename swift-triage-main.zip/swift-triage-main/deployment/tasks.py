"""Task scenarios: Easy, Medium, Hard."""

TASKS = {
    "easy": {
        "name": "Calm Shift",
        "difficulty": "easy",
        "description": "2 patients, plenty of resources. Learn the basics.",
        "config": {"total_beds": 10, "max_ticks": 20, "arrival_rate": 0.2, "seed": 100},
        "pass_threshold": 0.50,
    },
    "medium": {
        "name": "Busy Evening",
        "difficulty": "medium",
        "description": "5 patients with mixed severity under moderate load.",
        "config": {"total_beds": 8, "max_ticks": 50, "arrival_rate": 0.8, "seed": 200},
        "pass_threshold": 0.35,
    },
    "hard": {
        "name": "Mass Casualty",
        "difficulty": "hard",
        "description": "10+ patients flooding in, only 2 beds. Extreme pressure.",
        "config": {"total_beds": 2, "max_ticks": 100, "arrival_rate": 2.5, "seed": 300},
        "pass_threshold": 0.20,
    },
}
