import { formatDistanceToNow } from "date-fns";
import { ESIBadge } from "./ESIBadge";
import { StatusIndicator } from "@/components/clinical/StatusIndicator";
import type { Patient } from "@/lib/triage-data";
import { Heart, Thermometer, Wind, Droplets } from "lucide-react";

interface PatientQueueProps {
  patients: Patient[];
  selectedId: string | null;
  onSelect: (id: string) => void;
}

export function PatientQueue({ patients, selectedId, onSelect }: PatientQueueProps) {
  const sorted = [...patients].sort((a, b) => {
    if (a.esiLevel !== b.esiLevel) return a.esiLevel - b.esiLevel;
    return a.arrivalTime.getTime() - b.arrivalTime.getTime();
  });

  return (
    <div className="flex flex-col gap-2">
      <h2 className="px-1 text-sm font-semibold text-muted-foreground uppercase tracking-wider">
        Patient Queue
      </h2>
      <div className="flex flex-col gap-1.5">
        {sorted.map((patient) => {
          const statusVariant =
            patient.status === "treating"
              ? "treating" as const
              : patient.esiLevel <= 2
              ? "critical" as const
              : patient.status === "waiting"
              ? "waiting" as const
              : "discharged" as const;

          return (
            <button
              key={patient.id}
              onClick={() => onSelect(patient.id)}
              className={`w-full rounded-lg border p-3 text-left transition-colors ${
                selectedId === patient.id
                  ? "border-primary/50 bg-primary/5"
                  : "border-border bg-card hover:bg-accent/50"
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-sm truncate">{patient.name}</span>
                    <span className="text-xs text-muted-foreground">
                      {patient.age}{patient.gender}
                    </span>
                  </div>
                  <p className="mt-0.5 text-xs text-muted-foreground truncate">
                    {patient.chiefComplaint}
                  </p>
                </div>
                <ESIBadge level={patient.esiLevel} />
              </div>

              <div className="mt-2 flex items-center gap-3 text-xs text-muted-foreground">
                <span className="flex items-center gap-1">
                  <Heart className="h-3 w-3" /> {patient.vitals.hr}
                </span>
                <span className="flex items-center gap-1">
                  <Droplets className="h-3 w-3" /> {patient.vitals.spo2}%
                </span>
                <span className="flex items-center gap-1">
                  <Thermometer className="h-3 w-3" /> {patient.vitals.temp}°
                </span>
                <span className="flex items-center gap-1">
                  <Wind className="h-3 w-3" /> {patient.vitals.rr}
                </span>
                <span className="ml-auto">
                  {formatDistanceToNow(patient.arrivalTime, { addSuffix: true })}
                </span>
              </div>

              <div className="mt-1.5">
                <StatusIndicator variant={statusVariant} format="pill" size="sm" />
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
