import { ClinicalMetric } from "@/components/clinical/ClinicalMetric";
import { Activity, Clock, Users, AlertTriangle } from "lucide-react";
import type { Patient } from "@/lib/triage-data";

interface StatsBarProps {
  patients: Patient[];
}

export function StatsBar({ patients }: StatsBarProps) {
  const waiting = patients.filter((p) => p.status === "waiting").length;
  const treating = patients.filter((p) => p.status === "treating").length;
  const critical = patients.filter((p) => p.esiLevel <= 2).length;

  const waitingPatients = patients.filter((p) => p.status === "waiting");
  const avgWait =
    waitingPatients.length > 0
      ? Math.round(
          waitingPatients.reduce(
            (sum, p) => sum + (Date.now() - p.arrivalTime.getTime()) / 60000,
            0
          ) / waitingPatients.length
        )
      : 0;

  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
      <ClinicalMetric
        icon={<Users className="h-3.5 w-3.5" />}
        label="Total Patients"
        value={patients.length}
        highlight="primary"
      />
      <ClinicalMetric
        icon={<Clock className="h-3.5 w-3.5" />}
        label="Waiting"
        value={waiting}
        highlight="warning"
      />
      <ClinicalMetric
        icon={<Activity className="h-3.5 w-3.5" />}
        label="In Treatment"
        value={treating}
        highlight="success"
      />
      <ClinicalMetric
        icon={<AlertTriangle className="h-3.5 w-3.5" />}
        label="Critical (ESI 1-2)"
        value={critical}
        highlight="danger"
      />
      <ClinicalMetric
        icon={<Clock className="h-3.5 w-3.5" />}
        label="Avg Wait"
        value={`${avgWait}m`}
      />
    </div>
  );
}
