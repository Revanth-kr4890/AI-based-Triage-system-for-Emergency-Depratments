import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import type { Patient, ESILevel } from "@/lib/triage-data";
import { UserPlus } from "lucide-react";
import { toast } from "sonner";

interface IntakeFormProps {
  onSubmit: (patient: Patient) => void;
}

export function PatientIntakeForm({ onSubmit }: IntakeFormProps) {
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [gender, setGender] = useState<"M" | "F" | "O">("M");
  const [complaint, setComplaint] = useState("");
  const [hr, setHr] = useState("80");
  const [bp, setBp] = useState("120/80");
  const [temp, setTemp] = useState("36.8");
  const [spo2, setSpo2] = useState("98");
  const [rr, setRr] = useState("16");
  const [painScale, setPainScale] = useState([5]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !complaint.trim()) {
      toast.error("Name and chief complaint are required");
      return;
    }

    const patient: Patient = {
      id: `P-${String(Date.now()).slice(-4)}`,
      name: name.trim(),
      age: parseInt(age) || 30,
      gender,
      chiefComplaint: complaint.trim(),
      esiLevel: 3 as ESILevel,
      status: "waiting",
      arrivalTime: new Date(),
      vitals: {
        hr: parseInt(hr) || 80,
        bp: bp || "120/80",
        temp: parseFloat(temp) || 36.8,
        spo2: parseInt(spo2) || 98,
        rr: parseInt(rr) || 16,
      },
      painScale: painScale[0],
    };

    onSubmit(patient);
    toast.success(`Patient ${patient.name} added to queue`);
    setName("");
    setAge("");
    setComplaint("");
  };

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4">
      <h2 className="flex items-center gap-2 text-sm font-semibold text-muted-foreground uppercase tracking-wider">
        <UserPlus className="h-4 w-4" />
        New Patient Intake
      </h2>

      <div className="grid grid-cols-3 gap-3">
        <div className="col-span-2">
          <Label className="text-xs text-muted-foreground">Full Name</Label>
          <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Patient name" className="mt-1 bg-muted/50" />
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div>
            <Label className="text-xs text-muted-foreground">Age</Label>
            <Input value={age} onChange={(e) => setAge(e.target.value)} placeholder="Age" type="number" className="mt-1 bg-muted/50" />
          </div>
          <div>
            <Label className="text-xs text-muted-foreground">Sex</Label>
            <Select value={gender} onValueChange={(v) => setGender(v as "M" | "F" | "O")}>
              <SelectTrigger className="mt-1 bg-muted/50">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="M">M</SelectItem>
                <SelectItem value="F">F</SelectItem>
                <SelectItem value="O">O</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      <div>
        <Label className="text-xs text-muted-foreground">Chief Complaint</Label>
        <Textarea value={complaint} onChange={(e) => setComplaint(e.target.value)} placeholder="Describe primary symptoms..." className="mt-1 bg-muted/50 resize-none" rows={2} />
      </div>

      <div>
        <Label className="text-xs text-muted-foreground mb-2 block">Vitals</Label>
        <div className="grid grid-cols-5 gap-2">
          <div>
            <span className="text-[10px] text-muted-foreground">HR</span>
            <Input value={hr} onChange={(e) => setHr(e.target.value)} className="bg-muted/50 font-mono text-xs" />
          </div>
          <div>
            <span className="text-[10px] text-muted-foreground">BP</span>
            <Input value={bp} onChange={(e) => setBp(e.target.value)} className="bg-muted/50 font-mono text-xs" />
          </div>
          <div>
            <span className="text-[10px] text-muted-foreground">Temp°C</span>
            <Input value={temp} onChange={(e) => setTemp(e.target.value)} className="bg-muted/50 font-mono text-xs" />
          </div>
          <div>
            <span className="text-[10px] text-muted-foreground">SpO₂</span>
            <Input value={spo2} onChange={(e) => setSpo2(e.target.value)} className="bg-muted/50 font-mono text-xs" />
          </div>
          <div>
            <span className="text-[10px] text-muted-foreground">RR</span>
            <Input value={rr} onChange={(e) => setRr(e.target.value)} className="bg-muted/50 font-mono text-xs" />
          </div>
        </div>
      </div>

      <div>
        <Label className="text-xs text-muted-foreground">Pain Scale: {painScale[0]}/10</Label>
        <Slider value={painScale} onValueChange={setPainScale} max={10} min={0} step={1} className="mt-2" />
      </div>

      <Button type="submit" className="w-full">
        <UserPlus className="mr-2 h-4 w-4" />
        Add Patient to Queue
      </Button>
    </form>
  );
}
