import { EDTriageEnvironment, type AgentAction, type EnvState, type StepResult } from "./EDTriageEnvironment";
import type { ESILevel } from "./triage-data";

// ─── Grader ──────────────────────────────────────────────────────────────────

export interface GradeReport {
  score: number;              // 0–1 normalised
  totalReward: number;        // raw cumulative reward
  maxPossibleReward: number;  // theoretical best
  triageAccuracy: number;     // 0–1
  mortalityEvents: number;
  avgWaitMinutes: number;
  throughput: number;         // discharged / arrivals
  criticalDelayPenalty: number;
  prioritizationBonus: number;
  breakdown: {
    rewardRatio: number;      // totalReward / maxPossible
    triageComponent: number;  // weighted contribution
    throughputComponent: number;
    mortalityPenalty: number;
    waitPenalty: number;
    criticalDelayPenalty: number;
    prioritizationBonus: number;
  };
}

// ─── Task list item ──────────────────────────────────────────────────────────

export interface TaskItem {
  id: string;
  description: string;
  patientId: string | null;
  priority: "critical" | "high" | "medium" | "low";
}

// ─── API Service ─────────────────────────────────────────────────────────────

export class TriageAPI {
  private env: EDTriageEnvironment;
  private actionLog: { tick: number; action: AgentAction; reward: number }[] = [];
  private cumulativeReward = 0;

  constructor(config?: ConstructorParameters<typeof EDTriageEnvironment>[0]) {
    this.env = new EDTriageEnvironment(config);
  }

  /** POST /reset — start a new simulation episode */
  reset(): EnvState {
    this.actionLog = [];
    this.cumulativeReward = 0;
    return this.env.reset();
  }

  /** GET /state — current environment snapshot */
  state(): EnvState {
    return this.env.state();
  }

  /** POST /step — apply an action, advance one tick */
  step(action: AgentAction): StepResult {
    const result = this.env.step(action);
    this.cumulativeReward += result.reward;
    this.actionLog.push({ tick: result.state.tick, action, reward: result.reward });
    return result;
  }

  /** GET /tasks — prioritised task list derived from current state */
  tasks(): TaskItem[] {
    const s = this.env.state();
    const items: TaskItem[] = [];

    // Untriaged patients (ESI still at default 3 with no explicit assignment)
    const waiting = s.patients.filter((p) => p.status === "waiting");
    const treating = s.patients.filter((p) => p.status === "treating");

    for (const p of waiting) {
      if (p.esiLevel <= 2) {
        items.push({ id: `treat-${p.id}`, description: `Treat high-acuity patient ${p.name} (ESI ${p.esiLevel})`, patientId: p.id, priority: "critical" });
      } else {
        items.push({ id: `triage-${p.id}`, description: `Assess waiting patient ${p.name}`, patientId: p.id, priority: "medium" });
      }
    }

    for (const p of treating) {
      items.push({ id: `discharge-${p.id}`, description: `Evaluate ${p.name} for discharge`, patientId: p.id, priority: "low" });
    }

    if (s.beds.occupied >= s.beds.total) {
      items.push({ id: "beds-full", description: "All beds occupied — prioritise discharges", patientId: null, priority: "high" });
    }

    // Sort by priority
    const order: Record<string, number> = { critical: 0, high: 1, medium: 2, low: 3 };
    items.sort((a, b) => order[a.priority] - order[b.priority]);
    return items;
  }

  /** GET /grader — normalised score 0–1 based on cumulative reward */
  grader(): GradeReport {
    const s = this.env.state();
    const m = s.metrics;

    // ── Step 1: Total reward (already tracked) ──────────────────────────
    const totalReward = this.cumulativeReward;

    // ── Step 2: Max possible reward estimate ────────────────────────────
    // Perfect run: every triage correct (+10), every treat rewards avg 6,
    // every discharge +3, minus 0.5/tick time penalty
    const perfectTriageReward = m.totalArrivals * 10;
    const perfectTreatReward = m.totalArrivals * 6;
    const perfectDischargeReward = m.totalArrivals * 3;
    const timePenalty = s.tick * 0.5;
    const maxPossibleReward = Math.max(1, perfectTriageReward + perfectTreatReward + perfectDischargeReward - timePenalty);

    // ── Component metrics ───────────────────────────────────────────────
    const triageAccuracy = m.totalMistriage === 0
      ? 1
      : Math.max(0, 1 - m.totalMistriage / Math.max(1, m.totalArrivals));

    const throughput = m.totalArrivals > 0 ? m.totalDischarged / m.totalArrivals : 0;

    // Penalty: critical patients left waiting (from action log)
    const criticalDelayPenalty = this.computeCriticalDelayPenalty(s);

    // Bonus: treating high-acuity before low-acuity (correct prioritisation)
    const prioritizationBonus = this.computePrioritizationBonus();

    // ── Step 3: Normalise to 0–1 ────────────────────────────────────────
    const rewardRatio = Math.max(0, Math.min(1, totalReward / maxPossibleReward));

    const weighted =
      rewardRatio * 0.35 +
      triageAccuracy * 0.25 +
      throughput * 0.15 +
      prioritizationBonus * 0.10 +
      Math.max(0, 0.15 - m.mortalityEvents * 0.05) +  // mortality eats into 15%
      Math.max(0, 0 - criticalDelayPenalty);            // penalty subtracts

    const score = Math.max(0, Math.min(1, +weighted.toFixed(4)));

    return {
      score,
      totalReward,
      maxPossibleReward: +maxPossibleReward.toFixed(1),
      triageAccuracy: +triageAccuracy.toFixed(3),
      mortalityEvents: m.mortalityEvents,
      avgWaitMinutes: m.avgWaitMinutes,
      throughput: +throughput.toFixed(3),
      criticalDelayPenalty: +criticalDelayPenalty.toFixed(3),
      prioritizationBonus: +prioritizationBonus.toFixed(3),
      breakdown: {
        rewardRatio: +(rewardRatio * 0.35).toFixed(4),
        triageComponent: +(triageAccuracy * 0.25).toFixed(4),
        throughputComponent: +(throughput * 0.15).toFixed(4),
        mortalityPenalty: +(Math.max(0, 0.15 - m.mortalityEvents * 0.05)).toFixed(4),
        waitPenalty: +(Math.min(0.1, m.avgWaitMinutes / 500)).toFixed(4),
        criticalDelayPenalty: +(-criticalDelayPenalty).toFixed(4),
        prioritizationBonus: +(prioritizationBonus * 0.10).toFixed(4),
      },
    };
  }

  /** Penalty for critical/high-acuity patients left waiting too long */
  private computeCriticalDelayPenalty(s: EnvState): number {
    const waiting = s.patients.filter((p) => p.status === "waiting");
    let penalty = 0;
    for (const p of waiting) {
      if (p.esiLevel <= 2) {
        penalty += 0.02 * (6 - p.esiLevel); // ESI 1 = 0.10, ESI 2 = 0.08 per patient
      }
    }
    return Math.min(0.15, penalty);
  }

  /** Bonus: did we treat high-acuity patients before low-acuity? */
  private computePrioritizationBonus(): number {
    const treatActions = this.actionLog
      .filter((a) => a.action.type === "treat")
      .map((a) => a.action as { type: "treat"; patientId: string });

    if (treatActions.length < 2) return 1; // trivially correct

    let correctOrder = 0;
    let total = 0;
    for (let i = 1; i < treatActions.length; i++) {
      total++;
      // Check reward: earlier treats of high-acuity patients got higher reward
      const prevReward = this.actionLog.find(
        (a) => a.action.type === "treat" && (a.action as any).patientId === treatActions[i - 1].patientId
      )?.reward ?? 0;
      const currReward = this.actionLog.find(
        (a) => a.action.type === "treat" && (a.action as any).patientId === treatActions[i].patientId
      )?.reward ?? 0;
      if (prevReward >= currReward) correctOrder++;
    }
    return total > 0 ? correctOrder / total : 1;
  }

  /** POST /baseline — run a simple rule-based agent to completion */
  baseline(): { finalState: EnvState; grade: GradeReport; log: typeof this.actionLog } {
    this.reset();

    while (!this.state().done) {
      const s = this.state();

      // Rule: triage any unassessed waiting patients by acuity heuristics
      const untriaged = s.patients.find((p) => p.status === "waiting" && p.esiLevel === 3 && p.vitals.spo2 < 90);
      if (untriaged) {
        const esi: ESILevel = untriaged.vitals.spo2 < 80 ? 1 : 2;
        this.step({ type: "triage", patientId: untriaged.id, assignedESI: esi });
        continue;
      }

      // Rule: treat highest-acuity waiting patient if beds available
      const toTreat = s.patients
        .filter((p) => p.status === "waiting")
        .sort((a, b) => a.esiLevel - b.esiLevel)[0];

      if (toTreat && s.beds.occupied < s.beds.total) {
        this.step({ type: "treat", patientId: toTreat.id });
        continue;
      }

      // Rule: discharge longest-treating patient
      const toDischarge = s.patients.find((p) => p.status === "treating");
      if (toDischarge) {
        this.step({ type: "discharge", patientId: toDischarge.id });
        continue;
      }

      this.step({ type: "noop" });
    }

    return { finalState: this.state(), grade: this.grader(), log: [...this.actionLog] };
  }
}
