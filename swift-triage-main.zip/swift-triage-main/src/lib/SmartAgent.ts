import { TriageAPI, type GradeReport } from "./TriageAPI";
import type { AgentAction, EnvState } from "./EDTriageEnvironment";
import type { ESILevel, Patient } from "./triage-data";

// ─── Vitals + Complaint-Based ESI Estimator ──────────────────────────────────

function estimateESI(p: Patient): ESILevel {
  const { hr, spo2, rr } = p.vitals;
  const sys = parseInt(p.vitals.bp.split("/")[0], 10);
  const complaint = p.chiefComplaint.toLowerCase();

  if (complaint.includes("cardiac arrest")) return 1;
  if (complaint.includes("chest pain")) return 1;
  if (spo2 < 75 || hr < 20 || hr > 155 || sys < 65) return 1;

  if (complaint.includes("respiratory distress")) return 2;
  if (complaint.includes("gi bleed") || (complaint.includes("bleed") && !complaint.includes("controlled"))) return 2;
  if (spo2 < 90) return 2;

  if (complaint.includes("rash") || complaint.includes("itching")) return 5;
  if (complaint.includes("sore throat")) return 5;
  if (complaint.includes("headache") && complaint.includes("no red flags")) return 4;
  if (complaint.includes("ankle") || complaint.includes("sprain")) return 4;

  return 3;
}

/** Urgency score — higher = more urgent. Uses estimated ESI + raw vitals */
function urgencyScore(p: Patient): number {
  const esi = estimateESI(p);
  const { spo2, hr, rr } = p.vitals;
  let score = (6 - esi) * 100;
  score += Math.max(0, 100 - spo2) * 5;
  score += Math.max(0, hr - 100) * 2;
  score += Math.max(0, rr - 20) * 3;
  return score;
}

// ─── Smart Agent ─────────────────────────────────────────────────────────────

export interface SmartAgentResult {
  finalState: EnvState;
  grade: GradeReport;
}

/**
 * Smart triage agent — key strategies:
 * 1. Triage + treat critical patients in quick succession
 * 2. Use urgency scoring from vitals+complaints for treatment order
 * 3. Aggressively discharge to maximize throughput
 * 4. Preempt bed shortages by discharging before treating critical arrivals
 */
export function runSmartAgent(api: TriageAPI): SmartAgentResult {
  api.reset();
  const triaged = new Set<string>();

  while (!api.state().done) {
    const s = api.state();
    const action = decideAction(s, triaged);
    if (action.type === "triage") triaged.add(action.patientId);
    api.step(action);
  }

  return { finalState: api.state(), grade: api.grader() };
}

function decideAction(s: EnvState, triaged: Set<string>): AgentAction {
  const waiting = s.patients.filter((p) => p.status === "waiting");
  const treating = s.patients.filter((p) => p.status === "treating");
  const bedsAvailable = s.beds.total - s.beds.occupied;

  // Sort waiting by estimated urgency
  const sorted = [...waiting].sort((a, b) => urgencyScore(b) - urgencyScore(a));
  const topPatient = sorted[0];

  if (topPatient) {
    const est = estimateESI(topPatient);

    // ── Critical patient needs triage first (for accuracy score) ─────────
    if (est <= 2 && !triaged.has(topPatient.id) && topPatient.esiLevel !== est) {
      return { type: "triage", patientId: topPatient.id, assignedESI: est };
    }

    // ── Free bed if needed for critical patient ─────────────────────────
    if (est <= 2 && bedsAvailable === 0 && treating.length > 0) {
      const leastUrgent = [...treating].sort((a, b) => estimateESI(b) - estimateESI(a))[0];
      return { type: "discharge", patientId: leastUrgent.id };
    }

    // ── Treat if bed available ──────────────────────────────────────────
    if (bedsAvailable > 0) {
      return { type: "treat", patientId: topPatient.id };
    }
  }

  // ── Discharge to cycle throughput ──────────────────────────────────────
  if (treating.length > 0) {
    const leastUrgent = [...treating].sort((a, b) => estimateESI(b) - estimateESI(a))[0];
    return { type: "discharge", patientId: leastUrgent.id };
  }

  return { type: "noop" };
}
