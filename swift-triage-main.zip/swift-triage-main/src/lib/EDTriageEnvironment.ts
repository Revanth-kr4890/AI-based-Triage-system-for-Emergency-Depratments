import type { Patient, ESILevel, PatientStatus } from "./triage-data";

// ─── Types ───────────────────────────────────────────────────────────────────

export type AgentAction =
  | { type: "triage"; patientId: string; assignedESI: ESILevel }
  | { type: "treat"; patientId: string }
  | { type: "discharge"; patientId: string }
  | { type: "noop" };

export interface EnvState {
  tick: number;
  patients: Patient[];
  beds: { total: number; occupied: number };
  metrics: {
    totalArrivals: number;
    totalDischarged: number;
    totalMistriage: number;
    avgWaitMinutes: number;
    mortalityEvents: number;
  };
  done: boolean;
}

export interface StepResult {
  state: EnvState;
  reward: number;
  done: boolean;
  info: Record<string, unknown>;
}

interface EnvConfig {
  totalBeds: number;
  maxTicks: number;
  arrivalRate: number; // avg new patients per tick
  seed?: number;
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

const COMPLAINTS: { complaint: string; trueESI: ESILevel; vitalsRange: Patient["vitals"] }[] = [
  { complaint: "Cardiac arrest", trueESI: 1, vitalsRange: { hr: 0, bp: "60/40", temp: 35.0, spo2: 70, rr: 4 } },
  { complaint: "Chest pain radiating to arm", trueESI: 1, vitalsRange: { hr: 120, bp: "180/110", temp: 37.2, spo2: 88, rr: 26 } },
  { complaint: "Severe respiratory distress", trueESI: 2, vitalsRange: { hr: 110, bp: "140/90", temp: 37.8, spo2: 85, rr: 30 } },
  { complaint: "Active GI bleed", trueESI: 2, vitalsRange: { hr: 105, bp: "95/60", temp: 36.9, spo2: 94, rr: 22 } },
  { complaint: "Abdominal pain, vomiting", trueESI: 3, vitalsRange: { hr: 92, bp: "130/85", temp: 38.4, spo2: 97, rr: 18 } },
  { complaint: "Deep laceration, bleeding controlled", trueESI: 3, vitalsRange: { hr: 84, bp: "125/80", temp: 36.8, spo2: 98, rr: 16 } },
  { complaint: "Ankle injury, unable to bear weight", trueESI: 4, vitalsRange: { hr: 76, bp: "118/72", temp: 36.9, spo2: 99, rr: 14 } },
  { complaint: "Mild rash, itching", trueESI: 5, vitalsRange: { hr: 72, bp: "115/70", temp: 36.6, spo2: 99, rr: 14 } },
  { complaint: "Sore throat, low-grade fever", trueESI: 5, vitalsRange: { hr: 78, bp: "120/75", temp: 38.0, spo2: 99, rr: 16 } },
  { complaint: "Headache, no red flags", trueESI: 4, vitalsRange: { hr: 80, bp: "128/78", temp: 36.7, spo2: 99, rr: 15 } },
];

const NAMES = [
  "Alex Rivera", "Jordan Lee", "Casey Patel", "Morgan Wu", "Riley Adams",
  "Taylor Kim", "Quinn Foster", "Avery Singh", "Drew Nakamura", "Sam Okafor",
  "Jamie Cruz", "Reese Chang", "Skyler Youssef", "Finley Brooks", "Dakota Ahn",
];

function seededRandom(seed: number): () => number {
  let s = seed;
  return () => {
    s = (s * 16807 + 0) % 2147483647;
    return s / 2147483647;
  };
}

function jitterVitals(base: Patient["vitals"], rand: () => number): Patient["vitals"] {
  const jitter = (v: number, pct: number) => +(v * (1 + (rand() - 0.5) * pct)).toFixed(1);
  const [sys, dia] = base.bp.split("/").map(Number);
  return {
    hr: Math.round(jitter(base.hr, 0.15)),
    bp: `${Math.round(jitter(sys, 0.1))}/${Math.round(jitter(dia, 0.1))}`,
    temp: jitter(base.temp, 0.02),
    spo2: Math.min(100, Math.max(50, Math.round(jitter(base.spo2, 0.05)))),
    rr: Math.round(jitter(base.rr, 0.15)),
  };
}

// ─── Environment ─────────────────────────────────────────────────────────────

export class EDTriageEnvironment {
  private config: EnvConfig;
  private rand: () => number;
  private _state!: EnvState;
  private patientCounter = 0;
  private trueESIMap = new Map<string, ESILevel>();

  constructor(config: Partial<EnvConfig> = {}) {
    this.config = {
      totalBeds: config.totalBeds ?? 20,
      maxTicks: config.maxTicks ?? 100,
      arrivalRate: config.arrivalRate ?? 1.5,
      seed: config.seed ?? 42,
    };
    this.rand = seededRandom(this.config.seed!);
    this.reset();
  }

  /** Reset environment to initial state, return starting state */
  reset(): EnvState {
    this.rand = seededRandom(this.config.seed!);
    this.patientCounter = 0;
    this.trueESIMap.clear();

    const initialPatients = this.generatePatients(5);

    this._state = {
      tick: 0,
      patients: initialPatients,
      beds: { total: this.config.totalBeds, occupied: 0 },
      metrics: {
        totalArrivals: initialPatients.length,
        totalDischarged: 0,
        totalMistriage: 0,
        avgWaitMinutes: 0,
        mortalityEvents: 0,
      },
      done: false,
    };

    return this.state();
  }

  /** Return a deep-copy snapshot of the current state */
  state(): EnvState {
    return structuredClone(this._state);
  }

  /** Advance one tick with the given action, return { state, reward, done, info } */
  step(action: AgentAction): StepResult {
    if (this._state.done) {
      return { state: this.state(), reward: 0, done: true, info: { error: "episode_over" } };
    }

    let reward = 0;
    const info: Record<string, unknown> = {};

    // ── Process action ───────────────────────────────────────────────────
    switch (action.type) {
      case "triage": {
        const p = this._state.patients.find((pt) => pt.id === action.patientId);
        if (!p) {
          reward -= 1;
          info.error = "patient_not_found";
          break;
        }
        const trueESI = this.trueESIMap.get(p.id)!;
        p.esiLevel = action.assignedESI;
        const diff = Math.abs(action.assignedESI - trueESI);
        if (diff === 0) {
          reward += 10;
          info.triageAccuracy = "correct";
        } else {
          // Under-triaging (assigning higher number = lower acuity) is more dangerous
          const penalty = action.assignedESI > trueESI ? diff * -8 : diff * -3;
          reward += penalty;
          this._state.metrics.totalMistriage++;
          info.triageAccuracy = "incorrect";
          info.trueESI = trueESI;
        }
        break;
      }
      case "treat": {
        const p = this._state.patients.find((pt) => pt.id === action.patientId);
        if (!p || p.status !== "waiting") {
          reward -= 1;
          info.error = p ? "not_waiting" : "patient_not_found";
          break;
        }
        if (this._state.beds.occupied >= this._state.beds.total) {
          reward -= 2;
          info.error = "no_beds";
          break;
        }
        p.status = "treating";
        this._state.beds.occupied++;
        // Reward treating high-acuity patients faster
        reward += (6 - p.esiLevel) * 2;
        break;
      }
      case "discharge": {
        const p = this._state.patients.find((pt) => pt.id === action.patientId);
        if (!p || p.status !== "treating") {
          reward -= 1;
          info.error = p ? "not_treating" : "patient_not_found";
          break;
        }
        p.status = "discharged";
        this._state.beds.occupied = Math.max(0, this._state.beds.occupied - 1);
        this._state.metrics.totalDischarged++;
        reward += 3;
        break;
      }
      case "noop":
        break;
    }

    // ── Deterioration & mortality check for waiting patients ──────────────
    for (const p of this._state.patients) {
      if (p.status === "waiting") {
        const waitMinutes = (this._state.tick - 0) * 5; // each tick = 5 min
        const trueESI = this.trueESIMap.get(p.id) ?? 3;
        // High-acuity patients deteriorate faster
        if (trueESI <= 2 && waitMinutes > 15) {
          const mortalityChance = trueESI === 1 ? 0.08 : 0.02;
          if (this.rand() < mortalityChance) {
            this._state.metrics.mortalityEvents++;
            p.status = "discharged"; // removed from queue (death event)
            reward -= 50;
            info.mortalityEvent = p.id;
          }
        }
      }
    }

    // ── New arrivals ─────────────────────────────────────────────────────
    const numArrivals = this.poissonSample(this.config.arrivalRate);
    if (numArrivals > 0) {
      const newPatients = this.generatePatients(numArrivals);
      this._state.patients.push(...newPatients);
      this._state.metrics.totalArrivals += numArrivals;
    }

    // ── Update metrics ───────────────────────────────────────────────────
    const waitingPatients = this._state.patients.filter((p) => p.status === "waiting");
    this._state.metrics.avgWaitMinutes = waitingPatients.length > 0
      ? Math.round(waitingPatients.reduce((sum, p) => {
          const waitTicks = this._state.tick;
          return sum + waitTicks * 5;
        }, 0) / waitingPatients.length)
      : 0;

    // ── Advance tick ─────────────────────────────────────────────────────
    this._state.tick++;
    if (this._state.tick >= this.config.maxTicks) {
      this._state.done = true;
    }

    // Small time penalty to encourage efficient action
    reward -= 0.5;

    return { state: this.state(), reward, done: this._state.done, info };
  }

  // ── Private helpers ──────────────────────────────────────────────────────

  private generatePatients(count: number): Patient[] {
    const patients: Patient[] = [];
    for (let i = 0; i < count; i++) {
      this.patientCounter++;
      const template = COMPLAINTS[Math.floor(this.rand() * COMPLAINTS.length)];
      const name = NAMES[Math.floor(this.rand() * NAMES.length)];
      const id = `P-${String(this.patientCounter).padStart(3, "0")}`;

      const patient: Patient = {
        id,
        name,
        age: Math.floor(this.rand() * 70) + 10,
        gender: (["M", "F", "O"] as const)[Math.floor(this.rand() * 3)],
        chiefComplaint: template.complaint,
        esiLevel: 3, // unassigned — agent must triage
        status: "waiting",
        arrivalTime: new Date(),
        vitals: jitterVitals(template.vitalsRange, this.rand),
        painScale: Math.floor(this.rand() * 10) + 1,
      };

      this.trueESIMap.set(id, template.trueESI);
      patients.push(patient);
    }
    return patients;
  }

  private poissonSample(lambda: number): number {
    let L = Math.exp(-lambda);
    let k = 0;
    let p = 1;
    do {
      k++;
      p *= this.rand();
    } while (p > L);
    return k - 1;
  }
}
