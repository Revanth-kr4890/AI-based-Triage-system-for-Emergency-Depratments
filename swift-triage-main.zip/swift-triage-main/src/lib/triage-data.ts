export type ESILevel = 1 | 2 | 3 | 4 | 5;

export type PatientStatus = "waiting" | "treating" | "discharged";

export interface Patient {
  id: string;
  name: string;
  age: number;
  gender: "M" | "F" | "O";
  chiefComplaint: string;
  esiLevel: ESILevel;
  status: PatientStatus;
  arrivalTime: Date;
  vitals: {
    hr: number;
    bp: string;
    temp: number;
    spo2: number;
    rr: number;
  };
  painScale: number;
}

export const ESI_LABELS: Record<ESILevel, string> = {
  1: "Resuscitation",
  2: "Emergent",
  3: "Urgent",
  4: "Less Urgent",
  5: "Non-Urgent",
};

export const ESI_CLASSES: Record<ESILevel, { bg: string; text: string; border: string }> = {
  1: { bg: "esi-1", text: "esi-1-text", border: "esi-1-border" },
  2: { bg: "esi-2", text: "esi-2-text", border: "esi-2-border" },
  3: { bg: "esi-3", text: "esi-3-text", border: "esi-3-border" },
  4: { bg: "esi-4", text: "esi-4-text", border: "esi-4-border" },
  5: { bg: "esi-5", text: "esi-5-text", border: "esi-5-border" },
};

export const MOCK_PATIENTS: Patient[] = [
  {
    id: "P-001",
    name: "James Morrison",
    age: 67,
    gender: "M",
    chiefComplaint: "Chest pain, radiating to left arm",
    esiLevel: 1,
    status: "treating",
    arrivalTime: new Date(Date.now() - 15 * 60000),
    vitals: { hr: 112, bp: "180/110", temp: 37.2, spo2: 91, rr: 24 },
    painScale: 9,
  },
  {
    id: "P-002",
    name: "Sarah Chen",
    age: 34,
    gender: "F",
    chiefComplaint: "Severe abdominal pain, vomiting",
    esiLevel: 2,
    status: "waiting",
    arrivalTime: new Date(Date.now() - 25 * 60000),
    vitals: { hr: 98, bp: "130/85", temp: 38.6, spo2: 97, rr: 20 },
    painScale: 8,
  },
  {
    id: "P-003",
    name: "Robert Williams",
    age: 45,
    gender: "M",
    chiefComplaint: "Laceration on forearm, moderate bleeding",
    esiLevel: 3,
    status: "waiting",
    arrivalTime: new Date(Date.now() - 40 * 60000),
    vitals: { hr: 82, bp: "125/80", temp: 36.8, spo2: 98, rr: 16 },
    painScale: 5,
  },
  {
    id: "P-004",
    name: "Maria Garcia",
    age: 28,
    gender: "F",
    chiefComplaint: "Ankle sprain, unable to bear weight",
    esiLevel: 4,
    status: "waiting",
    arrivalTime: new Date(Date.now() - 55 * 60000),
    vitals: { hr: 76, bp: "118/72", temp: 36.9, spo2: 99, rr: 14 },
    painScale: 6,
  },
  {
    id: "P-005",
    name: "David Kim",
    age: 52,
    gender: "M",
    chiefComplaint: "Difficulty breathing, wheezing",
    esiLevel: 2,
    status: "treating",
    arrivalTime: new Date(Date.now() - 35 * 60000),
    vitals: { hr: 105, bp: "140/90", temp: 37.0, spo2: 89, rr: 28 },
    painScale: 4,
  },
  {
    id: "P-006",
    name: "Linda Thompson",
    age: 71,
    gender: "F",
    chiefComplaint: "Confusion, slurred speech",
    esiLevel: 1,
    status: "treating",
    arrivalTime: new Date(Date.now() - 8 * 60000),
    vitals: { hr: 88, bp: "195/105", temp: 36.5, spo2: 95, rr: 18 },
    painScale: 2,
  },
  {
    id: "P-007",
    name: "Ahmed Hassan",
    age: 19,
    gender: "M",
    chiefComplaint: "Sore throat, fever for 2 days",
    esiLevel: 5,
    status: "waiting",
    arrivalTime: new Date(Date.now() - 70 * 60000),
    vitals: { hr: 78, bp: "120/75", temp: 38.1, spo2: 99, rr: 16 },
    painScale: 3,
  },
  {
    id: "P-008",
    name: "Patricia Novak",
    age: 42,
    gender: "F",
    chiefComplaint: "Migraine, photophobia, nausea",
    esiLevel: 3,
    status: "waiting",
    arrivalTime: new Date(Date.now() - 48 * 60000),
    vitals: { hr: 84, bp: "132/82", temp: 36.7, spo2: 99, rr: 15 },
    painScale: 7,
  },
];
