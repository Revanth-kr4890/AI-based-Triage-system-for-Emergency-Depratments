import { TriageAPI } from "./TriageAPI";
import type { AgentAction } from "./EDTriageEnvironment";
import type { ESILevel } from "./triage-data";

// ─── Task Definitions ────────────────────────────────────────────────────────

export interface TaskScenario {
  name: string;
  difficulty: "easy" | "medium" | "hard";
  description: string;
  config: {
    totalBeds: number;
    maxTicks: number;
    arrivalRate: number;
    seed: number;
  };
  expectedPatients: number;
  timeLimit: number; // in ticks
}

// 🟢 Easy: 2 patients, 2 doctors (plenty of beds)
export const TASK_EASY: TaskScenario = {
  name: "Calm Shift",
  difficulty: "easy",
  description: "2 patients, 2 doctors, plenty of resources. Learn the basics.",
  config: {
    totalBeds: 10,
    maxTicks: 20,
    arrivalRate: 0.2, // very few new arrivals
    seed: 100,
  },
  expectedPatients: 2,
  timeLimit: 20,
};

// 🟡 Medium: 5 patients, mixed severity
export const TASK_MEDIUM: TaskScenario = {
  name: "Busy Evening",
  difficulty: "medium",
  description: "5 patients with mixed severity. Prioritise correctly under moderate load.",
  config: {
    totalBeds: 8,
    maxTicks: 50,
    arrivalRate: 0.8,
    seed: 200,
  },
  expectedPatients: 5,
  timeLimit: 50,
};

// 🔴 Hard: 10+ patients, only 1-2 doctors (very few beds)
export const TASK_HARD: TaskScenario = {
  name: "Mass Casualty",
  difficulty: "hard",
  description: "10+ patients flooding in, only 2 beds available. Triage under extreme pressure.",
  config: {
    totalBeds: 2,
    maxTicks: 100,
    arrivalRate: 2.5, // heavy arrivals
    seed: 300,
  },
  expectedPatients: 10,
  timeLimit: 100,
};

export const ALL_TASKS: TaskScenario[] = [TASK_EASY, TASK_MEDIUM, TASK_HARD];

// ─── Task Runner ─────────────────────────────────────────────────────────────

export interface TaskResult {
  scenario: TaskScenario;
  grade: ReturnType<TriageAPI["grader"]>;
  ticks: number;
  passed: boolean;
}

/** Run baseline agent against a scenario and return results */
export function runTask(scenario: TaskScenario): TaskResult {
  const api = new TriageAPI({
    ...scenario.config,
    // Override initial patients via seed + arrivalRate
  });

  const { grade, finalState } = api.baseline();

  const passThresholds = { easy: 0.50, medium: 0.35, hard: 0.20 };
  const passed = grade.score >= passThresholds[scenario.difficulty];

  return {
    scenario,
    grade,
    ticks: finalState.tick,
    passed,
  };
}

/** Run all three tasks and return summary */
export function runAllTasks(): TaskResult[] {
  return ALL_TASKS.map(runTask);
}
